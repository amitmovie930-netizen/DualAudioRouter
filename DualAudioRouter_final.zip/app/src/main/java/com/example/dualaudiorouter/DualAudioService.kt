package com.example.dualaudiorouter

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import androidx.annotation.Keep
import java.lang.reflect.Method

/**
 * Shizuku User Service that runs as shell UID 2000.
 * Uses reflection for all @SystemApi AudioManager methods.
 */
class DualAudioService : IDualAudioService.Stub {

    private var audioManager: AudioManager? = null

    constructor()

    @Keep
    constructor(context: Context) {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override fun destroy() {
        clearDualOutput()
        audioManager = null
        System.exit(0)
    }

    override fun setDualOutput(speakerType: Int, btType: Int) {
        val am = audioManager ?: return
        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val speaker = devices.firstOrNull { it.type == speakerType } ?: return
        val btDevice = devices.firstOrNull { it.type == btType } ?: return

        val strategy = findMediaStrategy() ?: return

        // Create AudioDeviceAttributes via reflection
        val attrClass = try {
            Class.forName("android.media.AudioDeviceAttributes")
        } catch (_: Exception) {
            return
        }
        val ctor = attrClass.getConstructor(AudioDeviceInfo::class.java)
        val speakerAttr = ctor.newInstance(speaker)
        val btAttr = ctor.newInstance(btDevice)
        val list = listOf(speakerAttr, btAttr)

        invokeSetPreferredDevicesForStrategy(am, strategy, list)
    }

    override fun clearDualOutput() {
        val am = audioManager ?: return
        val strategy = findMediaStrategy() ?: return
        invokeRemovePreferredDeviceForStrategy(am, strategy)
    }

    override fun isDualActive(): Boolean {
        val am = audioManager ?: return false
        val strategy = findMediaStrategy() ?: return false
        val preferred = invokeGetPreferredDevicesForStrategy(am, strategy)
        return preferred != null && preferred.size > 1
    }

    private fun findMediaStrategy(): Any? {
        return try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val getStrategies: Method = strategyClass.getMethod("getAudioProductStrategies")
            @Suppress("UNCHECKED_CAST")
            val strategies = getStrategies.invoke(null) as? List<Any> ?: return null

            val mediaAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val supportsMethod = try {
                strategyClass.getMethod("supportsAudioAttributes", AudioAttributes::class.java)
            } catch (_: NoSuchMethodException) {
                null
            }

            if (supportsMethod != null) {
                for (strategy in strategies) {
                    val supports = supportsMethod.invoke(strategy, mediaAttrs) as? Boolean
                    if (supports == true) return strategy
                }
            }

            strategies.firstOrNull()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun invokeSetPreferredDevicesForStrategy(
        am: AudioManager,
        strategy: Any,
        devices: List<Any>
    ) {
        try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = AudioManager::class.java.getMethod(
                "setPreferredDevicesForStrategy",
                strategyClass,
                java.util.List::class.java
            )
            method.invoke(am, strategy, devices)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun invokeRemovePreferredDeviceForStrategy(
        am: AudioManager,
        strategy: Any
    ) {
        try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = try {
                AudioManager::class.java.getMethod(
                    "removePreferredDeviceForStrategy",
                    strategyClass
                )
            } catch (_: NoSuchMethodException) {
                AudioManager::class.java.getMethod(
                    "clearPreferredDevicesForStrategy",
                    strategyClass
                )
            }
            method.invoke(am, strategy)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Suppress("UNCHECKED_CAST")
    private fun invokeGetPreferredDevicesForStrategy(
        am: AudioManager,
        strategy: Any
    ): List<Any>? {
        return try {
            val strategyClass = Class.forName("android.media.audiopolicy.AudioProductStrategy")
            val method = AudioManager::class.java.getMethod(
                "getPreferredDevicesForStrategy",
                strategyClass
            )
            method.invoke(am, strategy) as? List<Any>
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
