package com.example.dualaudiorouter

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import android.media.AudioDeviceInfo
import android.media.AudioManager

@Composable
fun DualAudioUI(
    onToggle: (Boolean) -> Unit,
    onCheckShizuku: () -> Unit
) {
    val context = LocalContext.current
    var dualActive by remember { mutableStateOf(false) }
    var shizukuRunning by remember { mutableStateOf(rikka.shizuku.Shizuku.isPreV13().not()) }
    var btConnected by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val am = context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager
        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        btConnected = devices.any { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Dual Audio Router",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (!shizukuRunning) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("⚠️ Shizuku is not running")
                    Text("Start Shizuku via ADB, then tap below to retry.")
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = onCheckShizuku) {
                        Text("Check Shizuku")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        if (!btConnected) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "⚠️ No Bluetooth A2DP device connected. Pair your speaker first.",
                    modifier = Modifier.padding(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dual Audio (Speaker + Bluetooth)")
            Spacer(modifier = Modifier.width(16.dp))
            Switch(
                checked = dualActive,
                onCheckedChange = { enabled ->
                    dualActive = enabled
                    onToggle(enabled)
                },
                enabled = shizukuRunning && btConnected
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "When enabled, all media audio (Netflix, YouTube, music) plays on both the internal speaker and the Bluetooth speaker simultaneously.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
