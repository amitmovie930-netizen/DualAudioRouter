package com.example.dualaudiorouter;

interface IDualAudioService {
    void destroy() = 16777114;
    void setDualOutput(int speakerType, int btType) = 1;
    void clearDualOutput() = 2;
    boolean isDualActive() = 3;
}
