package com.example.dualaudiorouter

import android.content.ComponentName
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import rikka.shizuku.Shizuku
import rikka.shizuku.UserServiceArgs
import rikka.shizuku.ServiceConnection

class MainActivity : ComponentActivity() {

    private var service: IDualAudioService? = null
    private var isBound = false
    
    private val serviceConnection = object : ServiceConnection() {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IDualAudioService.Stub.asInterface(binder)
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            isBound = false
        }
    }

    private val permissionCallback = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            bindUserService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addOnRequestPermissionResultListener(permissionCallback)
        checkAndRequestPermission()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    DualAudioUI(
                        onToggle = { enabled ->
                            try {
                                if (enabled) {
                                    service?.setDualOutput(
                                        AudioDeviceInfo.TYPE_SPEAKER,
                                        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                                    )
                                } else {
                                    service?.clearDualOutput()
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        },
                        onCheckShizuku = { checkAndRequestPermission() }
                    )
                }
            }
        }
    }

    private fun checkAndRequestPermission() {
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            bindUserService()
        } else {
            Shizuku.requestPermission(1001)
        }
    }

    private fun bindUserService() {
        if (isBound || service != null) return
        
        val args = UserServiceArgs(
            ComponentName(packageName, DualAudioService::class.java.name)
        ).apply {
            processName("dual_audio_service")
            version(1)
            debug(BuildConfig.DEBUG)
        }

        try {
            Shizuku.bindUserService(args, serviceConnection)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeOnRequestPermissionResultListener(permissionCallback)
        if (isBound) {
            val args = UserServiceArgs(
                ComponentName(packageName, DualAudioService::class.java.name)
            )
            try {
                Shizuku.unbindUserService(args, serviceConnection, true)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
