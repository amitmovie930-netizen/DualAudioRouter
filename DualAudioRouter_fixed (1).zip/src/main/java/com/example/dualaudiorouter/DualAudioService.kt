package com.example.dualaudiorouter

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import java.util.List

class DualAudioService : IDualAudioService.Stub {

    private var audioManager: AudioManager? = null
    private var deviceCallback: AudioManager.OnAudioDevicesChangedListener? = null

    constructor(context: Context) : super() {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        setupDeviceCallback()
    }

    override fun destroy() {
        clearDualOutput()
        deviceCallback?.let { audioManager?.removeOnAudioDevicesChangedListener(it) }
        System.exit(0)
    }

    override fun setDualOutput(speakerType: Int, btType: Int) {
        val am = audioManager ?: return
        try {
            val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val speaker = devices.firstOrNull { it.type == speakerType }
            val btDevice = devices.firstOrNull { it.type == btType }

            if (speaker == null || btDevice == null) return

            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val method = AudioManager::class.java.getMethod(
                "setPreferredDevicesForStrategy",
                AudioAttributes::class.java,
                java.util.List::class.java
            )
            method.invoke(am, attributes, listOf(speaker, btDevice))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun clearDualOutput() {
        val am = audioManager ?: return
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val method = AudioManager::class.java.getMethod(
                "clearPreferredDevicesForStrategy",
                AudioAttributes::class.java
            )
            method.invoke(am, attributes)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun isDualActive(): Boolean {
        val am = audioManager ?: return false
        return try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .build()

            val method = AudioManager::class.java.getMethod(
                "getPreferredDevicesForStrategy",
                AudioAttributes::class.java
            )
            val devices = method.invoke(am, attributes) as? java.util.List<*>
            (devices?.size ?: 0) > 1
        } catch (e: Exception) {
            false
        }
    }

    private fun setupDeviceCallback() {
        val am = audioManager ?: return
        deviceCallback = AudioManager.OnAudioDevicesChangedListener { devices ->
            if (isDualActive()) {
                val btDevice = devices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP }
                if (btDevice == null) {
                    clearDualOutput()
                }
            }
        }
        am.addOnAudioDevicesChangedListener(
            Handler(Looper.getMainLooper()),
            deviceCallback!!
        )
    }
}
